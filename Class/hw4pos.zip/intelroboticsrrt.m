%% intelrobotics HW4 RRT %%

clc
clear

% Config Space
grid_size = 200;
num_obstacles = 6000; 
start_pos = [50, 50]; 
goal_pos = [150, 150]; 

% Create Obstacles
grid = zeros(grid_size, grid_size); 
for i = 1:num_obstacles
    x = randi(grid_size);
    y = randi(grid_size);
    grid(x, y) = 1; 
end

% Run RRT
[tree, path] = rrt(grid_size, num_obstacles, start_pos, goal_pos, grid);

if ~isempty(path)
    disp('Path found :) :');
    disp(path);
    close all
    plot_rrt(grid_size, num_obstacles, start_pos, goal_pos, tree, path, grid);
else
    disp('No path found :(');
end

% RRT Algorithm
function [tree, path] = rrt(grid_size, num_obstacles, start_pos, goal_pos, grid)
    tree = struct('parent', [], 'position', start_pos);
    
    % Iteration Parameters
    max_iter = 20000;
    step_size = 1;
    goal_radius = 10;
    
  
    for iter = 1:max_iter
        
        %Creat Branches
        rand_point = [randi(grid_size), randi(grid_size)];
        
        node = findnode(tree, rand_point);
        new_point = tdist(node.position, rand_point, step_size);
        
        % Check if next point is Valid
        if neighbors(grid, new_point)
            neztnode.parent = node;
            neztnode.position = new_point;
            tree(end+1) = neztnode;
            
            % Check if the goal is reached
            if norm(new_point - goal_pos) <= goal_radius
                path = reconpath(tree, numel(tree));
                return;
            end
        end
    end
    % No path found
    path = []; 
end

% Find Nearest Node
function node = findnode(tree, point)
    distances = arrayfun(@(node) norm(node.position - point), tree);
    [~, idx] = min(distances);

    node = tree(idx);
end

function point = tdist(current_point, target_point, step_size)
    direction = target_point - current_point;
    distance = norm(direction);

    if distance <= step_size
        point = target_point;
    else
        point = current_point + (step_size / distance) * direction;
    end
end

% Reconstruct Path
function path = reconpath(tree, goal_idx)
    path = [];
    current_node = tree(goal_idx);
    while ~isempty(current_node)

        path = [path; current_node.position];
        current_node = current_node.parent;
    end
    path = flipud(path); 
end

function getneighbors = neighbors(grid, point)
    x = round(point(1));
    y = round(point(2));
    getneighbors = x >= 1 && x <= size(grid, 1) && ...
            y >= 1 && y <= size(grid, 2) && ...
            grid(x, y) == 0; 
end

% Plot RRT
function plot_rrt(grid_size, num_obstacles, start_pos, goal_pos, tree, path, grid)
    figure;
    imagesc(grid);
    colormap([1 1 1; 0 0 0]);
    hold on;
    
    % Plot start and goal
    plot(start_pos(2), start_pos(1), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    text(start_pos(2), start_pos(1), 'Start');
    plot(goal_pos(2), goal_pos(1), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    text(goal_pos(2), goal_pos(1), 'Goal');
    
    % Plot RRT branches
    for i = 2:numel(tree)
        tnode = tree(i);
        parenode = tnode.parent;
        if ~isempty(parenode)
            plot([parenode.position(2), tnode.position(2)], [parenode.position(1), tnode.position(1)], 'k-', 'LineWidth', 1);
        end
    end
    
    % Plot path
    if ~isempty(path)
        x_path = path(:, 1);
        y_path = path(:, 2);
        plot(y_path, x_path, 'b-', 'LineWidth', 2);
    end
    
    axis equal;
    xlabel('Columns');
    ylabel('Rows');
    title('RRT');
end