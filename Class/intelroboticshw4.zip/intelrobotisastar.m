%% intelrobotics HW4 Astar %%

clc
clear

%Config Space
grid_size = 200;
num_obstacles = 2000;
start_pos = [50, 50];
goal_pos = [150, 150];

%Create Obstacles
for i = 1:num_obstacles
    x = randi(grid_size);
    y = randi(grid_size);
    grid(x, y) = 1; 
end
close all


% Run A*
path = astar_algorithm(grid_size, num_obstacles, start_pos, goal_pos, grid);

if ~isempty(path)
    disp('Path found :)');
    close all;
    plot_astar_path(grid_size, num_obstacles, start_pos, goal_pos, path, grid);
else
    disp('No path found :(');
end




function path = astar_algorithm(grid_size, num_obstacles, start_pos, goal_pos, grid)

    open_set = {start_pos};
    came_from = containers.Map();
    score = containers.Map();
    score(num2str(start_pos)) = 0;
    
    % A* algorithm loop
    while ~isempty(open_set)
       
        current_pos = open_set{1};
        open_set(1) = [];
        
        % Check if reached the goal
        if isequal(current_pos, goal_pos)
            path = reconstruct_path(came_from, goal_pos);
            return;
        end
        
        % Check Neighboring NOdes
        neighbors = get_neighbors(current_pos, grid_size);
        for i = 1:size(neighbors, 1)
            neighbor_pos = neighbors(i, :);
            
            
            if grid(neighbor_pos(1), neighbor_pos(2)) == 1
                continue;
            end
            
            % Calculate Cost
            tentative_g_score = score(num2str(current_pos)) + 1;
            
            % Update if this path is better than prev
            if ~score.isKey(num2str(neighbor_pos)) || tentative_g_score < score(num2str(neighbor_pos))
                came_from(num2str(neighbor_pos)) = current_pos;
                score(num2str(neighbor_pos)) = tentative_g_score;
                
                
                if ~any(cellfun(@(pos) isequal(pos, neighbor_pos), open_set))
                    open_set{end+1} = neighbor_pos;
                end
            end
        end
    end
    
    % No path found
    path = [];
end

% Cost
function h = cost(pos, goal_pos)
    h = abs(pos(1) - goal_pos(1)) + abs(pos(2) - goal_pos(2));
end

% Build Path Post Algo
function path = reconstruct_path(came_from, goal_pos)
    path = [];
    current_pos = goal_pos;
    while came_from.isKey(num2str(current_pos))
        path = [current_pos; path];
        current_pos = came_from(num2str(current_pos));
    end
    path = [current_pos; path];
end


% Check if Point is Valid
function neighbors = get_neighbors(pos, grid_size)
    directions = [0, 1; 0, -1; 1, 0; -1, 0];
    neighbors = pos + directions;
    
    valid = all(neighbors >= 1, 2) & all(neighbors <= grid_size, 2);
    neighbors = neighbors(valid, :);
end

% Plot A*
function plot_astar_path(grid_size, num_obstacles, start_pos, goal_pos, path,grid)
    
    figure;
    imagesc(grid);
    colormap([1 1 1; 0 0 0]); 
    hold on;
    
    %Plot start and goal
    plot(start_pos(2), start_pos(1), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    text(start_pos(2), start_pos(1), 'Start');
    plot(goal_pos(2), goal_pos(1), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    text(goal_pos(2), goal_pos(1), 'Goal');
  
    if ~isempty(path)
        x_path = path(:, 2);
        y_path = path(:, 1);
        plot(x_path, y_path, 'b-', 'LineWidth', 2);
    end
    
    axis equal;
    xlabel('Columns');
    ylabel('Rows');
    title('A*');
end